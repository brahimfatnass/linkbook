import { IoTicketOutline } from "react-icons/io5";
import React from "react"
import Cmp1 from "../compo/comp1/page";
import Cmp2 from "../compo/comp2/page";
import module from "./p.module.css";
import Cm3 from "../dashb/header/navv"
const hpage = () => {
  return (
    <div className={module.div}>
    <h1  className={module.h}>mes offres :</h1>
    <div className={module.div2}>
    <IoTicketOutline className={module.d} />
      <h2>partager un nouvele offre</h2>

    </div>
    <Cmp1/>
    <Cmp2/>
    <Cm3/>
    </div>
  )
}

export default hpage
