import React from 'react';
import Link from 'next/link';
//import Image from 'next/image'; 
import module from './f.module.css';
import { CiFacebook } from "react-icons/ci";
import { CiTwitter } from "react-icons/ci";
import { BsInstagram } from "react-icons/bs";

const Footer = () => {
  return (
    <div className={module.back}>
        <hr/>
        <img src="/a.jpeg" alt="Description of image" width={500} height={300} className={module.image}/>
        <hr  className={module.custom}/>
        <div className={module.container}>
            <Link href="/" className={module.link}>Home</Link>
            <Link href="/about" className={module.link}>About</Link>
           <Link href="/services" className={module.link}>Services</Link>
           <Link href="/contact" className={module.link}>Contact</Link>
            <Link href="/blog" className={module.link}>Blog</Link>
            <Link href="/faq" className={module.link}>FAQ</Link>
            <Link href="/privacy" className={module.link}>Privacy Policy</Link>
        </div>
        <hr className={module.custom}/>
        <div  className={module.containe}>
          <span className={module.item}> <button   style={{ borderColor: "blue" }} className={module.buton}><Link href="https://facebook.com" className={module.link1}><CiFacebook  style={{ color: "blue" }}/></Link></button></span>
          <span className={module.item}><button style={{ borderColor: "rgb(0, 140, 255)" }}  className={module.buton}><Link href="https://twitter.com" className={module.link1}><CiTwitter  style={{ color: "rgb(54, 179, 211)" }} /></Link></button></span>
          <span className={module.item}><button style={{ borderColor: "pink" }} className={module.buton}><Link href="https://instagram.com" className={module.link1}><BsInstagram style={{ color: "rgb(207, 45, 159)" }}/></Link></button></span>
        </div>
    </div>
  );
};

export default Footer;