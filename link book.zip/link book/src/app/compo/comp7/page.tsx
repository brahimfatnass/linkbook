import React from "react";
import "./App.css"; // Import the CSS file for styling
import { MdOutlineMailOutline } from "react-icons/md";
import { BsTelephoneInbound } from "react-icons/bs";
import { BiMessageRoundedDots } from "react-icons/bi";

const App = () => {
  return (
    <div className="container">
      <div className="profile">
        <img src="/brahim.jpg" alt="Profile" className="profile-image" />
        <div className="profile-details">
          <h1 className="profile-name">Malek Makki</h1>
          <h2 className="location">Sfax</h2>
          <h3 className="role">Endu</h3>
          <p className="description">Livre 3eme anne</p>
        </div>
      </div>

      <div className="actions">
        <button className="action-button"  style={{backgroundColor:"orangered"}}>
          <BiMessageRoundedDots className="icon" /> Message
        </button>
        <button className="action-button"  style={{backgroundColor:"blue"}}>
          <MdOutlineMailOutline className="icon" /> Email
        </button>
        <button className="action-button"  style={{backgroundColor:"green"}}>
          <BsTelephoneInbound className="icon" /> Telephone
        </button>
      </div>
    </div>
  );
};

export default App;