import React from "react";
import "./App.css"; // Import the CSS file for styling

const App = () => {
  return (
    <div className="container">
      <h1 className="title">TARIF</h1>
      <p className="description">
        Lorem ipsum est simplement un faux texte de l'industrie de l'impression et de la composition. Le Lorem ipsum est
        le texte factice standard de l'industrie depuis les années 1500, lorsqu'un imprimeur inconnu a pris une galère de
        caractères et l'a brouillé pour en faire un livre.
      </p>

      <div className="pricing-cards">
        {/* Pricing Card 1 */}
        <div className="card">
          <h2 className="card-title">10 pieces</h2>
          <p className="card-price">50 DT</p>
          <p className="card-description">
            Lorem ipsum est simplement: Lorem ipsum est simplement:
          </p>
          <button className="card-button">Acheter</button>
        </div>

        {/* Pricing Card 2 */}
        <div className="car">
          <h2 className="card-titl">20 pieces</h2>
          <p className="card-price" style={{color:"white"}}>100 DT</p>
          <p className="card-description" style={{color:"white"}}>
            Lorem ipsum est simplement: Lorem ipsum est simplement:
          </p>
          <button  style={{border:"white",backgroundColor:"rgb(14, 180, 204)",color:"white"}} className="card-button">Acheter</button>
        </div>

        {/* Pricing Card 3 */}
        <div className="card">
          <h2 className="card-title">30 pieces</h2>
          <p className="card-price">150 DT</p>
          <p className="card-description">
            Lorem ipsum est simplement: Lorem ipsum est simplement:
          </p>
          <button className="card-button" >Acheter</button>
        </div>
      </div>
    </div>
  );
};

export default App;