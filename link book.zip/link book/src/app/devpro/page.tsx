"use client";
import React, { useState } from "react";
import module from "./p.module.css";
import { PiLineVertical } from "react-icons/pi";

const Hpage = () => {
  const [isVisible, setIsVisible] = useState(true);

  const handleButtonClick = () => {
    setIsVisible(false);
  };

  if (!isVisible) {
    return null; // Return null to render nothing if the component should be hidden
  }

  return (
    <div className={module.div}>
      <div className={module.divv}>
        <img src="a.jpeg" className={module.img} />
        <h1 className={module.h}>nous avons envoyer un code</h1>
        <h1 className={module.hh}>par email</h1>
        <h1 className={module.hhh}>veuiller saisir le code nous avon envoyer </h1>
        <div className={module.div1}>
          <div className={module.div2}>
            <PiLineVertical className={module.lo} />
          </div>
          <div className={module.div2}>
            <PiLineVertical className={module.lo} />
          </div>
          <div className={module.div2}>
            <PiLineVertical className={module.lo} />
          </div>
          <div className={module.div2}>
            <PiLineVertical className={module.lo} />
          </div>
        </div>
        <button className={module.b} onClick={handleButtonClick}>
          termine
        </button>
        <h3 className={module.h3}>renvoyeer le code</h3>
      </div>
    </div>
  );
};

export default Hpage;