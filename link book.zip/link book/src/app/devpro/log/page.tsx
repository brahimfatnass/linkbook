"use client";
import React, { useState } from "react";
import module from "./p.module.css";
import { CiLock } from "react-icons/ci";

const Hpage = () => {
  const [isVisible, setIsVisible] = useState(true);

  const handleButtonClick = () => {
    setIsVisible(false);
  };

  if (!isVisible) {
    return null; // Return null to render nothing if the component should be hidden
  }

  return (
    <div className={module.div}>
      <div className={module.divv}>
        <img src="../a.jpeg" className={module.img} />
        <h1 className={module.h}>mot de passe</h1>
      
       
        <div className={module.div1}>
          <div className={module.div2}>
          <CiLock className={module.lo}/>
          <h4  className={module.y}>mot de passe</h4>
          </div>
          <div className={module.div2}>
          <CiLock className={module.lo}/>
          <h4  className={module.y}>confirmer votre mot de passe</h4>
          </div>
       
        </div>
        <button className={module.b} onClick={handleButtonClick}>
         changer
        </button>
        <h3 className={module.h3}>renvoyeer</h3>
      </div>
    </div>
  );
};

export default Hpage;