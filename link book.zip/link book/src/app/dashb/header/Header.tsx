"use client";
import Link from 'next/link';
import { FaAngleDown } from "react-icons/fa";
import React, { useState } from 'react';
import { AiFillAlipayCircle } from "react-icons/ai";
import { FaLaptopCode } from "react-icons/fa";
import { FaLaptopHouse } from "react-icons/fa";
import { IoTicketOutline } from "react-icons/io5";
import { FaCartPlus } from "react-icons/fa6";
import { FiMessageCircle } from "react-icons/fi";
import { FaGem } from "react-icons/fa";
import module from './p.module.css';
import { PiLineVerticalLight } from "react-icons/pi";
import { TbLayoutSidebarRightExpandFilled } from "react-icons/tb";
import { HiOutlineSearchCircle } from "react-icons/hi";
import { GiShoppingCart } from "react-icons/gi";
import Nav from "./nav";
import Navv from "./navv";
import { HiOutlineMenu } from "react-icons/hi";

const HPage = () => {
  const [isNvVisible, setIsNavVisible] = useState(false);

  const toggleNavVisibility = () => {
    setIsNavVisible(!isNvVisible);
  };


  return (
    <header className={module.header}>
      {/* Shared parent container */}
      <div className={module.container}>
        {/* Nav component with dynamic opacity */}
        {isNvVisible && <Nav/>}
  
        {/* .logobu and other content */}
        <div className={module.ny}>
          <img
            src="/b.jpeg"
            alt="Navbar background"
            className={module.image5}
            onClick={toggleNavVisibility}/>

          <div className={module.hoverContainer}>
            {/* Toggle button */}
            <HiOutlineMenu
              className={module.logobu}
              onClick={toggleNavVisibility}
            
            />
          </div>

          <div className={module.div2}>
            <h2 style={{ color: "lightgray" }}>type</h2>
            <select>
              <option value=""></option>
              <option value="">hh</option>
              <option value="">hh</option>
              <option value="">hh</option>
              <option value="">hh</option>
            </select>
            <PiLineVerticalLight />
            <input type="text" placeholder="ou..." />
            <HiOutlineSearchCircle className={module.hh} />
          </div>

          <div>
            <div className={module.div3}>
              <h6 className={module.hh} style={{ fontSize: "1.7em" }}>25</h6>
              <GiShoppingCart className={module.hh} style={{ backgroundColor: "transparent", color: "orange" }} />

              <div>
                <img src="/brahim.jpg" alt="Description of image" className={module.image2} />
                <ul className={module.ull}>
                  <li><Link href="#" className={module.class}>creator:Ibrahim Fatnassi</Link></li>
                  <li><Link href="#" className={module.class}>universety:isetn</Link></li>
                  <li><Link href="#" className={module.class}>company;</Link></li>
                  <li><Link href="#" className={module.class}>ph:90644897</Link></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default HPage;