import React from 'react'
import Cmp from "./com/page";
import Cmp1 from "../../compo/comp7/page"
import module from "./a.module.css"; 
import Na from "../../dashb/header/navv"; 
const page = () => {
  return (
    <div className={module.div}>
     <Cmp1 className={module.div}/>
     <Cmp className={module.div}/>

   <Na/>
    </div>
  )
}

export default page
