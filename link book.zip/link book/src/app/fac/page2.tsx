"use client";
import React from 'react'
import module from "./pp.module.css";
import { PiLineVerticalLight } from "react-icons/pi";
import { AiOutlinePicture } from "react-icons/ai";
import { MdAttachFile } from "react-icons/md";
import { LuSend } from "react-icons/lu";
import { CiMicrophoneOn } from "react-icons/ci";
export default function Page1({ title, children }) {
  return (
    <div className={module.div}>
          <div className={module.div1}>
     <img src="./brahim.jpg" className={module.img}/>
     <h1 className={module.h}>{title}</h1>
     <h2 className={module.hh}>11:20 pm</h2>
     </div>
     <div className={module.div2}>
     <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aut similique laboriosam, perferendis iusto temporibus sunt atque, facere dolorem, nostrum vero unde quo! Velit cumque doloribus debitis dicta modi eos corrupti.</p>
     <div className={module.u}>
     <img src="./nom4.jpg" className={module.img1}/>
     <img src="./o.jpg" className={module.img1}/>
     </div>
     </div>
     <div className={module.div3}>
     <h2 className={module.i}>11:20 pm</h2>
     
     <p className={module.d}>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aut similique laboriosam, perferendis iusto temporibus sunt atque, facere dolorem, nostrum vero unde quo! Velit cumque doloribus debitis dicta modi eos corrupti.</p>
     </div>
     <div className={module.div4}>
     <PiLineVerticalLight  className={module.l} />
     <div  className={module.di}>
     <CiMicrophoneOn  className={module.lo}/>
     <AiOutlinePicture  className={module.loo}/>
     <MdAttachFile  className={module.loy}/>
     <LuSend  className={module.looo}/>
     </div>
     </div>
    </div>
  )
}


